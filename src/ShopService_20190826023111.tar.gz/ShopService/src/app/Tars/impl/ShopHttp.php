<?php
namespace App\Tars\impl;
use App\Models\ShopConfig;
use Illuminate\Http\Request;
use App\Models\Shop as store;
use App\Models\ShareModel;
use App\Models\Banks;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\DB;
use  SimpleSoftwareIO\QrCode\Facades\QrCode;
use EasyWeChat\Factory;
class ShopHttp
{
    /**@商家后台start*/
    //添加试用版店铺信息
    public function addTrialShop()
    {
        $request=Request();
        $res = store::addshop($request);
        return json_encode($res);
    }
    //正式订购-创建店铺流程
    public function addFormalShop(){
        $request=Request();
        $res = store::addFormalShop($request);
        return json_encode($res);
    }

    //查询某个商家下面有几个店
    public function userShop(){
        $request=Request();
        $res = store::userShop($request);
        return json_encode($res);
    }
    //查询多店版下面有几个店铺
    public function userShopMany(){
        $request=Request();
        $res = store::userShopMany($request);
        return json_encode($res);
    }
    //查询店铺信息
    public function selectShop(){
        $request=Request();
        $store_id=$request->input('store_id','');
        $res=store::find($store_id);
        return json_encode(['code'=>0,'data'=>$res]);
    }
    //完善店铺信息
    public function perfectShop(){
        $request=Request();
        $res=store::perfectShop($request);
        return json_encode($res);
    }
    //绑定支付商户号
    public function merchant(){
        $request=Request();
        $store_id=$request->input('store_id','');
        $merchant=$request->input('merchant','');
        $res=store::where('id',$store_id)->update(['merchant'=>$merchant,'status'=>1]);
        if($res){
            return json_encode(['code'=>200,'data'=>'成功']);
        }else{
            return json_encode(['code'=>400,'msg'=>'失败']);
        }
    }
    //绑定微信公众号回调
    public function callback(){
        $request=Request();
        $store_id=$request->input('store_id','');
        $res=store::where('id',$store_id)->update(['status'=>2]);
        if($res){
            return json_encode(['code'=>200,'data'=>'成功']);
         }else{
            return json_encode(['code'=>400,'msg'=>'失败']);
         }
    }
    //更换域名
    public function replace(){
        $request=Request();
        $store_id=$request->input('store_id','');
        $domain=$request->input('domain','');
        $res=store::where('id',$store_id)->update(['domain'=>$domain,'status'=>3]);
        if($res){
            return json_encode(['code'=>200,'data'=>'成功']);
        }else{
            return json_encode(['code'=>400,'msg'=>'失败']);
        }
    }
    //商家的公众号店铺配置
    public function app_config(){
        $request=Request();
        $store_id=$request->input('store_id','');
        $app_id=$request->input('app_id','');
        $secret=$request->input('secret','');
        $aes_key=$request->input('aes_key','');
        if(!$store_id||!$app_id||!$secret||!$aes_key){
            return json_encode(['code'=>400,'msg'=>'缺少参数']);
        }else{
            $store=ShopConfig::where('store_id',$store_id)->select()->get()->toArray();
            $data=[
                'app_id'=>$app_id,
                'secret'=>$secret,
                'aes_key'=>$aes_key,
            ];
            if(count($store)>0){
                $res=ShopConfig::where('store_id',$store_id)->update($data);
            }else{
                $data['store_id']=$store_id;
                $res=ShopConfig::insert($data);
            }
            return json_encode(['code'=>200,'data'=>$res]);
        }
    }
    //商家公众号的配置信息
    public function config_info(){
        $request=Request();
        $store_id=$request->input('store_id','');
        $info=ShopConfig::where('store_id',$store_id)->first();
        return json_encode(['code'=>200,'data'=>$info]);
    }
    /*@商家后台end@*/
    /*@平台start@*/
    //查询平台设置的分类
    public function platformType(){
        $channe= store::platformType();
        return json_encode(['code'=>0,'data'=>$channe]);
    }
    //查询平台店铺列表
    public function platSelectShop(){
        $request=Request();
        $row=$request->input('row','20');
        $collection=store::platSelectShop($row);
        return json_encode(['code'=>200,'data'=>$collection]);
    }
    //查询某家店铺得详细信息
    public function platSelectShopOne(){
        $request=Request();
        $store_id=$request->input('store_id','');
        $res=store::platSelectShopOne($store_id);
        return json_encode(['code'=>200,'data'=>$res]);
    }
    //平台确定审核，客户经理对接
    public function platDockingShop(){
        $request=Request();
        $store_id=$request->input('store_id','');
        $contacts=$request->input('contacts','');
        if(!$contacts||!$store_id){
            return json_encode(['code'=>400,'msg'=>'缺少参数']);
        }
        $res=store::platDockingShop($store_id,$contacts);
        return json_encode(['code'=>200,'data'=>$res]);
    }
    //平台的店铺管理列表
    public function platShoplist(){
        $request=Request();
        $row=$request->input('row','20');
        $search=$request->input('search','');
        $res = store::platShoplist($row,$search);
        return json_encode(['code'=>200,'data'=>$res]);
    }
    //切换店铺 (该店是单店还是多店铺)
    public function switchShop(){
        $request=Request();
        $store_id=$request->input('store_id','');
        if($store_id){
            $type=store::where(['id'=>$store_id])->value('pid');
            if($type>0){
                return json_encode(['code'=>200,'data'=>1]);//多店
            }else{
                return json_encode(['code'=>200,'data'=>2]);//单店
            }
        }else{
            return json_encode(['code'=>400,'msg'=>'缺少参数']);
        }
    }
    //公众号授权给微信开放平台  wxc4ac1f3f73d6c004  57b798f74f97979b771be8da763892c5
    public function generate(){
        $config = [
            'app_id'   => 'wxc4ac1f3f73d6c004',
            'secret'   => '57b798f74f97979b771be8da763892c5',
            'token'    => '',
            'aes_key'  => 'fe3aEcae7fAa163c2b628a08Ca67585b'
        ];
        $openPlatform = Factory::openPlatform($config);
        $url=$openPlatform->getPreAuthorizationUrl('https://www.bbddp.com/api/shop/test/callback');
        return redirect($url);
    }
    //查询搜索商家订单列表
    public function orderList(){
        $request=Request();
        $list= store::orderList($request);
        return json_encode($list);
    }
    //查询商家某条订单详情
    public function OrderInfo(){
        $request=Request();
        $id=$request->input('id','');
        $list= store::orderinfo($id);
        return json_encode(['code'=>200,'data'=>$list]);
    }
    /*@平台end@*/
    //分页查询
    public function shopList(){
        $list= store::shopList(1,2);
        return json_encode(['code'=>200,'data'=>$list]);
    }
    //微信公众号转发朋友圈朋友需要的参数
    public function forward(){
        $request=Request();
        $store_id=$request->input('store_id');
        $configure=ShopConfig::config($store_id);
        if(!$configure){
            return  json_encode(['code'=>400,'msg'=>'店铺配置未填写']);
        }
        $nonceStr = $this->createNonceStr(); //构造一个随机数，用来生成签名的一部分
        $timestamp=time();
        $url=$request->input('url');
        if(!$url){
            return json_encode(['code'=>400,'msg'=>'回调路径不能为空']);
        }

        $jsapiTicket = ShareModel::wx_get_jsapi_ticket();
        $string = "jsapi_ticket=$jsapiTicket&noncestr=$nonceStr&timestamp=$timestamp&url=$url"; //签名算法先按照ascII码排序
        $signature = sha1($string);  //对排序好的字符串加密
        $signPackage = array(
            "debug"     =>true,
            "appId"     => $configure['app_id'],
            "nonceStr"  => $nonceStr,
            "timestamp" =>$timestamp,
            "signature" => $signature,
            "jsApiList" => ['onMenuShareTimeline', 'onMenuShareAppMessage', 'onMenuShareQQ', 'onMenuShareWeibo']
        );
        return json_encode(['code'=>200,'data'=>$signPackage]);
    }
    //构造一个随机数，用来生成签名的一部分
    private function createNonceStr($length = 16) { //生成随机16个字符的字符串
        $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        $str = "";
        for ($i = 0; $i < $length; $i++) {
            $str .= substr($chars, mt_rand(0, strlen($chars) - 1), 1);
        }
        return $str;
    }
    //模糊匹配银行
    public function banksVague(){
        $request=request();
        $bank_name= $request->input('bank_name','');//银行
        $city= $request->input('city','');//银行名称
        $banck=Banks::selectBanks($bank_name,$city);
        return  json_encode(['code'=>200,'data'=>$banck]);

    }
}
