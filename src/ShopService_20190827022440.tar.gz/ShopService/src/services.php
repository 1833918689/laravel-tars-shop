<?php
// 以namespace的方式,在psr4的框架下对代码进行加载
return (include __DIR__ . '/config/tars.php')['services'];
